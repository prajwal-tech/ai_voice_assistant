import os
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from motor.motor_asyncio import AsyncIOMotorClient

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = FastAPI()

# Database setup
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
client = AsyncIOMotorClient(MONGO_URI)
db = client.ai_voice_assistant
chats_collection = db.chats

class ChatRequest(BaseModel):
    input_text: str

@app.get("/")
def home():
    return {"message": "AI Voice Assistant is running"}

@app.post("/chat")
async def chat(request: ChatRequest):
    input_text = request.input_text
    response_text = process_nlp(input_text)
    chat_record = {"input": input_text, "response": response_text}
    await chats_collection.insert_one(chat_record)
    logging.info(f"Chat recorded: {chat_record}")
    return chat_record

def process_nlp(text: str) -> str:
    intents = {
        "hello": "Hi there! How can I assist you?",
        "bye": "Goodbye! Have a great day!",
        "help": "I can help with basic queries. Try asking me something!"
    }
    for key, value in intents.items():
        if key in text.lower():
            return value
    return "I'm sorry, I didn't understand that."

@app.get("/chats")
async def get_chats():
    chats = await chats_collection.find().to_list(None)
    logging.info("Fetched chat history")
    return {"chats": chats}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
